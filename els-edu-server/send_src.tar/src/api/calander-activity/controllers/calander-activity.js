'use strict';

/**
 * calander-activity controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::calander-activity.calander-activity');
