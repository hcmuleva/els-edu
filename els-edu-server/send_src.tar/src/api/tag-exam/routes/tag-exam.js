'use strict';

/**
 * tag-exam router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::tag-exam.tag-exam');
