"use strict";

/**
 * subject-pricing service
 */

const { createCoreService } = require("@strapi/strapi").factories;

module.exports = createCoreService("api::subject-pricing.subject-pricing");
