"use strict";

/**
 * question controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::question.question");
