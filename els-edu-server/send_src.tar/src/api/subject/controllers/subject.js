'use strict';

/**
 * subject controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::subject.subject');
