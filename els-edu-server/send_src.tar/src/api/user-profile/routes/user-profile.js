'use strict';

/**
 * user-profile router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::user-profile.user-profile');
