"use strict";

/**
 * course-pricing service
 */

const { createCoreService } = require("@strapi/strapi").factories;

module.exports = createCoreService("api::course-pricing.course-pricing");
