'use strict';

/**
 * usersubscription controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::usersubscription.usersubscription');
