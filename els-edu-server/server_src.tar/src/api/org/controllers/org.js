'use strict';

/**
 * org controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::org.org');
