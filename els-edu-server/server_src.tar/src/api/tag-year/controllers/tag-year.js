'use strict';

/**
 * tag-year controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::tag-year.tag-year');
