'use strict';

/**
 * quiz-result router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::quiz-result.quiz-result');