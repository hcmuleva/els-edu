'use strict';

/**
 * calander-activity service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::calander-activity.calander-activity');
