'use strict';

/**
 * tag-exam controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::tag-exam.tag-exam');
