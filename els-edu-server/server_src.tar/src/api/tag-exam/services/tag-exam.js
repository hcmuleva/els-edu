'use strict';

/**
 * tag-exam service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::tag-exam.tag-exam');
