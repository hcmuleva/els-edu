import { QuizCreate } from './QuizCreate';
export const QuizEdit = QuizCreate;
